CREDITS

ExtJS port by Mike Wille:
http://github.com/digerata

MooTools port by Ryan Florence:
http://github.com/rpflorence

=====

Helpful bug reports filed by:
http://github.com/wadewinningham
http://github.com/tingletech
http://stuartcharlton.com
http://github.com/garrettdimon

=====

Licensed under MIT/GPL.

GPL license:
http://www.gnu.org/licenses/gpl.html

MIT license:
http://www.opensource.org/licenses/mit-license.php